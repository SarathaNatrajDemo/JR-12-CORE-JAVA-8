package com.demo.samples.day2.abstratc;

public class IOB extends Bank {

	@Override
	int getRateOfInterest() {
		// TODO Auto-generated method stub
		return 8;
	}

}
