package com.demo.samples.day2.abstratc;

public abstract class Bank {
	
	abstract int getRateOfInterest();

}
