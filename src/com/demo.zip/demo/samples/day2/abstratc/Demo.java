package com.demo.samples.day2.abstratc;

 abstract class Demo //abstract class  
{  
	//abstract method declaration  
	abstract void display();
	
	//concrete method - full defined method
	public void hello() {
		System.out.println(" helloooo - concrete method");
	}
}  