package com.demo.samples.day2.abstratc;

public class SBI extends Bank{

	

	@Override
	int getRateOfInterest() {
		// TODO Auto-generated method stub
		return 7;
	}

}
