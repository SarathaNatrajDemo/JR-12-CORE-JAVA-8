package com.demo.samples.day2.finla;

class Bike {
	final void run() {
		System.out.println("running");
	}
}
