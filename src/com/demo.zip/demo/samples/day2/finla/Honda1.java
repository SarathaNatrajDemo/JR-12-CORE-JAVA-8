package com.demo.samples.day2.finla;

 class MyBike {
}

class Honda1 extends MyBike {
	void run() {
		System.out.println("running safely with 100kmph");
	}

	public static void main(String args[]) {
		Honda1 honda = new Honda1();
		honda.run();
	}
}
