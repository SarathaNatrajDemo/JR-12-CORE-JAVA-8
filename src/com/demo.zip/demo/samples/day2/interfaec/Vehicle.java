package com.demo.samples.day2.interfaec;

public interface Vehicle {
	void changeGear();
	void speedUp();

}
