package com.demo.samples.day2.interfaec;

public interface Measureable {

}
