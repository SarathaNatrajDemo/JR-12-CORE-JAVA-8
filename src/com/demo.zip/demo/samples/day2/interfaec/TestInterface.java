package com.demo.samples.day2.interfaec;

//Interface declaration: by first user  
interface Drawable {
	void draw();
}

//Implementation: by second user  
class Rectangle implements Drawable {
	public void draw() {
		System.out.println("drawing rectangle");
	}
}

class Circle implements Drawable {
	public void draw() {
		System.out.println("drawing circle");
	}
}

//Using interface: by third user  
class TestInterface1 {
	public static void main(String args[]) {
		Drawable cirObj = new Circle();// In real scenario, object is provided by method e.g. getDrawable()
		cirObj.draw();
		
		Drawable rectObj = new Rectangle();// In real scenario, object is provided by method e.g. getDrawable()
		rectObj.draw();
	}
}
