package com.demo.samples.day3.conversion;

public class Animal {
	String name;
	public void nature() {
		System.out.println("Animal");
	}

}
