package com.demo.samples.day3.conversion;

public class Fish extends Animal{
	String color;
	@Override
	public void nature() {
		System.out.println("Aquatic Animal");
	}

}
