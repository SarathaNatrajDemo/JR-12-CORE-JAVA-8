package com.demo.samples.day3.conversion;

public class ImplicitConversion {
	public static void main(String args[]) {
		byte p = 12;
		System.out.println("byte value : " + p);
		// Implicit Typecasting
		short q = p;
		System.out.println("short value : " + q);
		int r = q;
		System.out.println("int value : " + r);
		long s = r;
		System.out.println("long value : " + s);
		float t = s;
		System.out.println("float value : " + t);
		double u = t;
		System.out.println("double value : " + u);
		char a = 97;
		System.out.println(a);
		char A = 65;
		System.out.println(A);
	}
}