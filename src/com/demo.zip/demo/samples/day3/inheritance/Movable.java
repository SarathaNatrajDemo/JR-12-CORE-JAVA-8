package com.demo.samples.day3.inheritance;

public interface Movable {
	public void run();
}
