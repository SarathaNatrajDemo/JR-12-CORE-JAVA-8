package com.demo.samples.day3.inheritance;

public class HybridInheritance
{
  public static void main(String[] args)
  {
    PersonClass obj = new PersonClass();
    obj.run();
    obj.speak();
    obj.show();
  }
}
