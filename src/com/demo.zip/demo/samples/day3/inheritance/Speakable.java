package com.demo.samples.day3.inheritance;

public interface Speakable {
	public void speak();
}
