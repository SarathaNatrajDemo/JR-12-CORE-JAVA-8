package com.demo.samples.day3.inheritance;

class PermanentEmp extends Person {
	double hike = 0.5;
}
