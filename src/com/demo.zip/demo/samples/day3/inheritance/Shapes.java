package com.demo.samples.day3.inheritance;

public class Shapes {
	public void area() {
	    System.out.println("The formula for area of ");
	  }
}
//Base class Polygon, -> Square , Circle -> both with have render methods