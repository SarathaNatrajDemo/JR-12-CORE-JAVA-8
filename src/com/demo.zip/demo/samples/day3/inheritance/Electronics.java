package com.demo.samples.day3.inheritance;

class Electronics {
	public Electronics() {
		System.out.println("Class Electronics");
	}

	public void deviceType() {
		System.out.println("Device Type: Electronics");
	}
}
