package com.demo.samples.day3.inheritance;

public class MultipleInheritenceTest {
	public static void main(String args[]) {
		Student stuObj = new Student();
		stuObj.reads();
		stuObj.writes();
	}
}
