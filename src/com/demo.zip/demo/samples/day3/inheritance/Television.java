package com.demo.samples.day3.inheritance;

class Television extends Electronics {
	public Television() {
		System.out.println("Class Television");
	}

	public void category() {
		System.out.println("Category - Television");
	}
}
