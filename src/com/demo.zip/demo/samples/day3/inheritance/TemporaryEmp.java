package com.demo.samples.day3.inheritance;

class TemporaryEmp extends Person {
	double hike = 0.35;
}
