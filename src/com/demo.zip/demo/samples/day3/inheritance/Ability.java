package com.demo.samples.day3.inheritance;

class Ability {
	public void show() {
		System.out.println("I am a person, I can speak and run !!");
	}
}
