package com.demo.samples.day3.inheritance;

class LED extends Television {
	public LED() {
		System.out.println("Class LED");
	}

	public void display_tech() {
		System.out.println("Display Technology- LED");
	}
}
