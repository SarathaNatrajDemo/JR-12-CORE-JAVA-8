package com.demo.samples.day3.inheritance;

public class MultilevelInheritance {
	public static void main(String[] arguments) {
		LED led = new LED();
		led.deviceType();
		led.category();
		led.display_tech();
	}
}
