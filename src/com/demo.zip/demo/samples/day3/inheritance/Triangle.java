package com.demo.samples.day3.inheritance;

public class Triangle extends Shapes{
	public void area() {
	    System.out.println("Triangle is � * base * height ");
	  }

}
