package com.demo.samples.day3.inheritance;

public interface Readable {
	void reads();
	
}
