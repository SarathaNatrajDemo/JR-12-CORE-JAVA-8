package com.demo.samples.day3.inheritance;

public class Circle extends Shapes{
	public void area() {
	    System.out.println("Circle is 3.14 * radius * radius ");
	  }

}
