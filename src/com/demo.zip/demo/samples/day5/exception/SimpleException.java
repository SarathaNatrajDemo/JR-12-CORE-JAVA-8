package com.demo.samples.day5.exception;

//Java program to demonstrate how exception is thrown.

class SimpleException {

	public static void main(String args[]) {

		String str = null;
		System.out.println(str.length());

	}
}
