package com.demo.samples.day5.thread;

public class SimpleThreadImplments implements Runnable {
	public void run() {
		System.out.println("thread is running...");
	}

	public static void main(String args[]) {
		SimpleThreadImplments m1 = new SimpleThreadImplments();
		Thread t1 = new Thread(m1); // Using the constructor Thread(Runnable r)
		t1.start();
	}

}
