package com.demo.samples.day4.flowcontrol;

class whileLoopDemo
{
    public static void main(String args[])
    {
        int x = 1;
  
        // Exit when x becomes greater than 4
        while (x <= 4)
        {
            System.out.println("Value of x:" + x);
  
            // Increment the value of x for
            // next iteration
            x++;
        }
    }
}
