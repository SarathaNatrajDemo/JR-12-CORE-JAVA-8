package com.demo.samples.day4.arrays;

//Java program to illustrate creating
//an array of objects

class Student {
	 int roll_no;
	 String name;

	Student(int roll_no, String name) {
		this.roll_no = roll_no;
		this.name = name;
	}
}