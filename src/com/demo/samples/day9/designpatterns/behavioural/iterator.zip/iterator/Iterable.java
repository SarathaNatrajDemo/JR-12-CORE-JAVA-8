package com.demo.samples.day9.designpatterns.behavioural.iterator;

public interface Iterable {
	public Iterator getIterator();
}
