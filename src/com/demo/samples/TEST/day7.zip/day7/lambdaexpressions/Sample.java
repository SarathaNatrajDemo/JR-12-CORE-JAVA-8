package com.demo.samples.day7.lambdaexpressions;

@FunctionalInterface
public interface Sample {
    void ab();
}