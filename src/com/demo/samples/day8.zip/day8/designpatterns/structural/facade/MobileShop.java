package com.demo.samples.day8.designpatterns.structural.facade;

public interface MobileShop {  
    public void modelNo();  
    public void price();  
}  

