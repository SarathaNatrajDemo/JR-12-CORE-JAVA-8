package com.demo.samples.day8.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestFailure {

	@Test
	void test() {
		fail("Not yet implemented");
	}
	@Test
	public void test1() {
		Aprogram a = new Aprogram();
		Aprogram b = new aprogram();	 
		assertTrue( b.myfun(3) == 2 );
		assertTrue( a.myfun(3) == 3 );
	}
	@Test
	public void test2() {
		//fail("Not yet implemented");
		aprogram a = new aprogram();
		aprogram b = new aprogram();
		assertTrue( b.myfun(3) == 4 );
		//assertTrue( a.myfun(3) == 1 );
	}
}
