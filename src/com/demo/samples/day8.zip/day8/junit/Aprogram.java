package com.demo.samples.day8.junit;

public class Aprogram {

	int x = 1;

	public int myfun(int y) {
		x = x + 1;
		return x;
	}

}
